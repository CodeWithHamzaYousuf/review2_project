<?php
    $state = $_POST['state']; 
    $local_govt = $_POST['LocalGovt']; 
  
  echo "You selected $local_govt local government in $state State Nigeria. Setup was Successful";

?>